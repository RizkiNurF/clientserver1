umur = 10

if 0 <= umur < 5:
    print("umur masih balita")
elif 5 <= umur < 12:
    print("umur masih anak-anak")
elif 12 <= umur < 19:
    print("umur masih remaja")
elif 19 <= umur < 60:
    print("umur sudah dewasa")
else:
    print("umur sudah renta")

