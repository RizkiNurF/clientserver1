class SegiTiga:
